package Math.pow;

public class Ativ_4 {
    public static void main(String[] args) {
        double resultado = Math.pow(3, 4);
        System.out.println("O resultado é: " + resultado);
    }
}