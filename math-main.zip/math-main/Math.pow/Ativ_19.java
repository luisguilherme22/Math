package Math.pow;

public class Ativ_19 {
    public static void main(String[] args) {
        double resultado = Math.pow(-1, 3);
        System.out.println("O resultado é: " + resultado);
    }
}