package Math.pow;

public class Ativ_16 {
    public static void main(String[] args) {
        double resultado = Math.pow(0.1, 2);
        System.out.println("O resultado é: " + resultado);
    }
}