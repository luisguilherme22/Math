package Math.pow;

public class Ativ_12 {
    public static void main(String[] args) {
        double resultado = Math.pow(8, 2);
        System.out.println("O resultado é: " + resultado);
    }
}