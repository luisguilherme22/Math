package AtividadesMathJava;

public class Atividade11 {
    public static void main(String[] args) {
        double resultado = Math.pow(6, 3);
        System.out.println("O resultado é: " + resultado);
    }
}
