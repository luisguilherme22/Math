package Math.pow;

public class Ativ_15 {
    public static void main(String[] args) {
        double resultado = Math.pow(2, -3);
        System.out.println("O resultado é: " + resultado);
    }
}