package AtividadesMathJava;

public class Atividade20 {
    public static void main(String[] args) {
        double resultado = Math.pow(0, 5);
        System.out.println("O resultado é: " + resultado);
    }
}
