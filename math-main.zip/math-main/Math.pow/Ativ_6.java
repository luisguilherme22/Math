package Math.pow;

public class Ativ_6 {
    public static void main(String[] args) {
        double resultado = Math.pow(2, 10);
        System.out.println("O resultado é: " + resultado);
    }
}