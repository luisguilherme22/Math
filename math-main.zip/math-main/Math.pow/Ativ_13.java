package Math.pow;

public class Ativ_13 {
    public static void main(String[] args) {
        double resultado = Math.pow(-3, 2);
        System.out.println("O resultado é: " + resultado);
    }
}