package Math.pow;

public class Ativ_9 {
    public static void main(String[] args) {
        double resultado = Math.pow(4, 0.5);
        System.out.println("O resultado é: " + resultado);
    }
}