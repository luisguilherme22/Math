package Math.pow;

public class Ativ_3 {
    public static void main(String[] args) {
        double resultado = Math.pow(10, 0);
        System.out.println("O resultado é: " + resultado);
    }
}