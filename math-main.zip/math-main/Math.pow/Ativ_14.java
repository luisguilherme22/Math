package AtividadesMathJava;

public class Atividade14 {
    public static void main(String[] args) {
        double resultado = Math.pow(9, 0.5);
        System.out.println("O resultado é: " + resultado);
    }
}
