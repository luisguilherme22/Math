package Math.pow;

public class Ativ_8 {
    public static void main(String[] args) {
        double resultado = Math.pow(1, 100);
        System.out.println("O resultado é: " + resultado);
    }
}