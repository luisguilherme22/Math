package AtividadesMathJava;

public class Atividade17 {
    public static void main(String[] args) {
        double resultado = Math.pow(100, 0.5);
        System.out.println("O resultado é: " + resultado);
    }
}
