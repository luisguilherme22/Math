package Math.pow;

public class Ativ_5 {
    public static void main(String[] args) {
            double resultado = Math.pow(7, 2);
            System.out.println("O resultado é: " + resultado);
        }
    }