package AtividadesMathJava;

public class Ativ_15 {
    public static void main(String[] args) {
        int resultado = (8 % 3) + (6 / 2);
        System.out.println("O resultado é: " + resultado);
    }
}
