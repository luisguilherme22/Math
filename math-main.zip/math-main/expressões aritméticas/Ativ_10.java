package Ex_Aritmeticas;

public class Ativ_10 {
        public static void main(String[] args) {
            int resultado = (8 + 2) * (6 - 4);
            System.out.println("Resultado: " + resultado);
        }
    }
