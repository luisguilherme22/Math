package AtividadesMathJava;

public class Ativ_19 {
    public static void main(String[] args) {
        int resultado = (16 % 5) * (7 - 3);
        System.out.println("O resultado é: " + resultado);
    }
}
