package AtividadesMathJava;

public class Ativ_14 {
    public static void main(String[] args) {
        int resultado = (15 - 5) * (int) Math.pow(3,2);
        System.out.println("O resultado é: " + resultado);
    }
}
