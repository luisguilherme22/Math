package AtividadesMathJava;

public class Ativ_16 {
    public static void main(String[] args) {
        int resultado = (7 + 5) - (3 * 2);
        System.out.println("O resultado é: " + resultado);
    }
}
