package AtividadesMathJava;

public class Ativ_17 {
    public static void main(String[] args) {
        int resultado = (9 * 9) - (81 / 9);
        System.out.println("O resultado é: " + resultado);
    }
}
