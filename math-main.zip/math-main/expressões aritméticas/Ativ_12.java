package AtividadesMathJava;

public class Ativ_12 {
    public static void main(String[] args) {
        int resultado = (12 / 3) + (18 / 6);
        System.out.println("O resultado é: " + resultado);
    }
}
