    package AtividadesMathJava;

    public class Ativ_13 {
        public static void main(String[] args) {
            int resultado = (int) Math.pow(2, 3) + 5 * 2;
            System.out.println("O resultado é: " + resultado);
        }
    }
