package AtividadesMathJava;

public class Ativ_20 {
    public static void main(String[] args) {
        int resultado = (10 + 5) / (int) Math.pow(2,2);
        System.out.println("O resultado é: " + resultado);
    }
}
