package Ex_Aritmeticas;

public class Ativ_4 {
        public static void main(String[] args) {
            int resultado = 100 / (2 + 3);
            System.out.println("Resultado: " + resultado);
        }
    }