package Ex_Aritmeticas;

public class Ativ_9 {
    public static void main(String[] args) {
        int resultado = 100 - (25 / 5);
        System.out.println("Resultado: " + resultado);
    }
}