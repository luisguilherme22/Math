package Ex_Aritmeticas;

public class Ativ_8 {
    public static void main(String[] args) {
        int resultado = 2 * (3 + 4) - 5;
        System.out.println("O resultado é = " + resultado);
    }
}