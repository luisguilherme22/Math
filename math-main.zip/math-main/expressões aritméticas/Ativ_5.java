package Ex_Aritmeticas;

public class Ativ_5 {
        public static void main(String[] args) {
            int resultado = 25 % 4;
            System.out.println("25 % 4 = " + resultado);
        }
    }