package AtividadesMathJava;

public class Ativ_18 {
    public static void main(String[] args) {
        int resultado = (50 / (5 + 5)) + 10;
        System.out.println("O resultado é: " + resultado);
    }
}
