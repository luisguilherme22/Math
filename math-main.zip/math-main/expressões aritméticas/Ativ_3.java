package Ex_Aritmeticas;

public class Ativ_3 {
        public static void main(String[] args) {
            int resultado = 15 + 3 * 2;
            System.out.println("Resultado: " + resultado);
        }
    }