package Ex_Aritmeticas;

public class Ativ_7 {
    public static void main(String[] args) {
        int resultado = (50 / 2) + (8 * 3);
        System.out.println("Resultado: " + resultado);
    }
}