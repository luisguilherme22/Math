package Ex_Aritmeticas;

public class Ativ_6 {
        public static void main(String[] args) {
            int resultado = (30 - 5) * (2 + 3);
            System.out.println("O resultado é = " + resultado);
        }
    }