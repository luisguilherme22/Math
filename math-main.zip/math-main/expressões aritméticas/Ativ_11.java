package AtividadesMathJava;

public class Ativ_11 {
    public static void main(String[] args) {
        int resultado = 45 % (7 + 3);
        System.out.println("O resultado é: " + resultado);
    }
}
