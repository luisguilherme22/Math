package Ex_Aritmeticas;

public class Ativ_1 {
        public static void main(String[] args) {
            int resultado = (10 + 5) * 2;
            System.out.println("Resultado: " + resultado);
        }
    }