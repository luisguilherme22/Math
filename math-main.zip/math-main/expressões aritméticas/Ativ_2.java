package Ex_Aritmeticas;

public class Ativ_2 {
        public static void main(String[] args) {
            int resultado = (20 - 4) / 2;
            System.out.println("Resultado: " + resultado);
        }
    }