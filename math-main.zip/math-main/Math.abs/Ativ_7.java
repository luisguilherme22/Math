package MathAbs;

public class Ativ_7 {
    public static void main(String[] args) {
        int numero = -1234;
        int valorAbsoluto = Math.abs(numero);
        System.out.println("O valor absoluto de " + numero + " é " + valorAbsoluto);
    }
}
