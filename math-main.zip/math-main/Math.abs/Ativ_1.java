package MathAbs;

public class Ativ_1 {
    public static void main(String[] args) {
        int numero = -10;
        int valorAbsoluto = Math.abs(numero);
        System.out.println("O valor absoluto de " + numero + " é " + valorAbsoluto);
    }
}
