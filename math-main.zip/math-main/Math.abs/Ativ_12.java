package MathAbs;

public class Ativ_12 {
    public static void main(String[] args) {
        double numero = -0.5;
        double valorAbsoluto = Math.abs(numero);
        System.out.println("O valor absoluto de " + numero + " é " + valorAbsoluto);
    }
}
