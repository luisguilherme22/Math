package MathAbs;

public class Ativ_17 {
    public static void main(String[] args) {
        double numero = 42;
        double valorAbsoluto = Math.abs(numero);
        System.out.println("O valor absoluto de " + numero + " é " + valorAbsoluto);
    }
}
