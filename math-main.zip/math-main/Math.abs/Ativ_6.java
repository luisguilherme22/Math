package MathAbs;

public class Ativ_6 {
    public static void main(String[] args) {
                int numero = -100;
                int valorAbsoluto = Math.abs(-100);
                System.out.println("O valor absoluto de " + numero + " é " + valorAbsoluto);
            }
        }
