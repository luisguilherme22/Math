package MathAbs;

public class Ativ_11 {
    public static void main(String[] args) {
        int numero = 50;
        int valorAbsoluto = Math.abs(numero);
        System.out.println("O valor absoluto de " + numero + " é " + valorAbsoluto);
    }
}
