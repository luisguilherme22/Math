package MathAbs;

public class Ativ_20 {
    public static void main(String[] args) {
        double numero = -500;
        double valorAbsoluto = Math.abs(numero);
        System.out.println("O valor absoluto de " + numero + " é " + valorAbsoluto);
    }
}
