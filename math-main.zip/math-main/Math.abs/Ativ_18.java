package MathAbs;

public class Ativ_18 {
    public static void main(String[] args) {
        double numero = -8-8;
        double valorAbsoluto = Math.abs(numero);
        System.out.println("O valor absoluto de " + numero + " é " + valorAbsoluto);
    }
}
