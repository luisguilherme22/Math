package MathAbs;

public class Ativ_10 {
    public static void main(String[] args) {
        int numero = -1;
        int valorAbsoluto = Math.abs(-1);
        System.out.println("O valor absoluto de " + numero + " é " + valorAbsoluto);
    }
}
