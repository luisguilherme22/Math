package MathAbs;

public class Ativ_8 {
    public static void main(String[] args) {
        double numero = 3.1415;
        double valorAbsoluto = Math.abs(numero);
        System.out.println("O valor absoluto de " + numero + " é " + valorAbsoluto);
    }
}
