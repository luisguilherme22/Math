package MathAbs;

public class Ativ_14 {
    public static void main(String[] args) {
        double numero = -777;
        double valorAbsoluto = Math.abs(-777);
        System.out.println("O valor absoluto de " + numero + " é " + valorAbsoluto);
    }
}
