package Math;

public class Ativ_10 {
    public static void main(String[] args) {
        double num = 400;
        double raizquadrada = Math.sqrt(num);

        System.out.println("A raiz quadrada de " + num + " É " + raizquadrada );
    }
}