package Math;

public class Atv18 {
    public static void main(String[] args) {
        double num = 36;
        double raizQuad = Math.sqrt(num);

        System.out.println("A raiz quadrada de " + num + " é: " + raizQuad);
    }
}

