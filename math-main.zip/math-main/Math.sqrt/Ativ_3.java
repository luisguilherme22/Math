package Math;

public class Ativ_3 {
    public static void main(String[] args) {

            double num = 2;
            double raizquadrada = Math.sqrt(num);
            double resultado = Math.round(raizquadrada * 100.0) / 100;
            System.out.println("A raiz quadrada de " + num + " É " + raizquadrada );
        }
    }