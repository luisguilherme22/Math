package Math;

public class Ativ_6 {
    public static void main(String[] args) {
            double num = 225;
            double raizquadrada = Math.sqrt(num);

            System.out.println("A raiz quadrada de " + num + " É " + raizquadrada );
        }
    }