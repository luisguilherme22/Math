package Math;

public class Atv20 {
    public static void main(String[] args) {
        double num = 169;
        double raizQuad = Math.sqrt(num);

        System.out.println("A raiz quadrada de " + num + " é: " + raizQuad);
    }
}
