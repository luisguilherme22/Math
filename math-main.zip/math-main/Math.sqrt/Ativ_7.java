package Math;

public class Ativ_7 {
    public static void main(String[] args) {
        double num = 0.25;
        double raizquadrada = Math.sqrt(num);

        System.out.println("A raiz quadrada de " + num + " É " + raizquadrada );
    }
}