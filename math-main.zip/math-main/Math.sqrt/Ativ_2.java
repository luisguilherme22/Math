package Math;

import java.sql.SQLOutput;

public class Ativ_2 {
    public static void main(String[] args) {
    double num = 81;
    double raizquadrada = Math.sqrt(num);

        System.out.println("A raiz quadrada de " + num + " É " + raizquadrada );
    }
}